// page init
jQuery(function(){
"use strict";
	ImageFitCont();
	FixedHeader();
});

// Image Fit Container
function ImageFitCont() {
	$('.imageFit').imgLiquid({
		fill: true,
        horizontalAlign: 'center',
        verticalAlign: 'center'
	});
}


// Innerpage Fixed Header
function FixedHeader() {
	var lastScrollTop = 0, delta = 5;
	$(window).scroll(function(event){
	   var st = $(this).scrollTop();
	   
	   if(Math.abs(lastScrollTop - st) <= delta)
		  return;
	   
	   if (st > lastScrollTop){
	   // downscroll code
	   $(".site-header").addClass('in-fix-head').css({padding:'8px 0'})
	   .hover(function(){
		   });
	   } else {
		  // upscroll code
		  $(".site-header").removeClass('in-fix-head').css({padding: '38px 0'});
	   }
	   lastScrollTop = st;
	});
}

$( function() {
	
	// Menu Overlay Boday Class
	$('#trigger-overlay').click(function(){
		$('body').addClass('modal-open');
	});
	$('.overlay-close').click(function(){
		$('body').removeClass('modal-open');
	});
	
	// Overlay Submenu
	$('.dropdown > a').click(function(e){
		e.preventDefault();
		$(this).closest('li').find('.sub-menu').slideToggle();
		$(this).toggleClass('open');
	});
	
	// Lightbox
    $('#aniimated-thumbnials').lightGallery({
        hash:false
    }); 
	
	// Clear Search Field
	$('.cs').clearSearch();
	
	// Countrycode Dropdown
	$("#phone").intlTelInput();
	
	// Star Rating
	$('.fa-rating').raty({
		half : true,
  		starHalf : 'fa fa-fw fa-star-half-o'	
	});
	
	// Star Rating readonly
	$('.fa-rating-readonly').raty({
		half : true,
		readOnly: true,
  		starHalf : 'fa fa-fw fa-star-half-o',
		score: function() {
			return $(this).attr('data-score');
		}
	});
	
	// Edit Place
	$('.btn-edit').on('click', function(e){
		e.preventDefault();
		var PDIV = $(this).closest('.fav-block');
		$(PDIV).addClass('editmode');
		$(PDIV).find('input').attr("readonly", false);
	});
	$('.btn-save').on('click', function(e){
		e.preventDefault();
		var PDIV = $(this).closest('.fav-block');
		$(PDIV).removeClass('editmode').addClass('saved');
		$(PDIV).find('input').attr("readonly", true);
		setTimeout(function(){
			$(PDIV).removeClass('saved');
		}, 1000);
	});
	
	// Date Time Picker
	$(".form_time").datetimepicker({
		minView: 0,
        maxView: 1,
		startView:1,
		formatViewType:'time',
		format: 'H:ii P',
		showMeridian:true
	});
	
	
});

















